
# Android PDF Viewer App

App Android Native (Kotlin) sederhana untuk menampilkan PDF dari assets menggunakan AndroidPdfViewer.

## Cara menjalankan
1. Buka project ini di Android Studio
2. Sinkronkan gradle
3. Jalankan di emulator atau perangkat

## Library
- [barteksc/AndroidPdfViewer](https://github.com/barteksc/AndroidPdfViewer)
